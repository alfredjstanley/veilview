/*
 * Cogl
 *
 * A Low Level GPU Graphics and Utilities API
 *
 * Copyright (C) 2010 Intel Corporation.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 *
 *
 * Authors:
 *   Neil Roberts <neil@linux.intel.com>
 */

#pragma once

#include "cogl/cogl-pipeline-private.h"

void
cogl_pipeline_progend_glsl_pre_change_notify (CoglPipeline      *pipeline,
                                              CoglPipelineState  change,
                                              const CoglColor   *new_color);

void
cogl_pipeline_progend_glsl_layer_pre_change_notify (CoglPipeline           *owner,
                                                    CoglPipelineLayer      *layer,
                                                    CoglPipelineLayerState  change);

gboolean
cogl_pipeline_progend_glsl_start (CoglPipeline *pipeline);

void
cogl_pipeline_progend_glsl_end (CoglPipeline  *pipeline,
                                unsigned long  pipelines_difference);

void
cogl_pipeline_progend_glsl_pre_paint (CoglPipeline    *pipeline,
                                      CoglFramebuffer *framebuffer);

int
_cogl_pipeline_progend_glsl_get_attrib_location (CoglPipeline *pipeline,
                                                 int name_index);
